var annotated_dup =
[
    [ "RWA2", null, [
      [ "AerialRobot", "class_r_w_a2_1_1_aerial_robot.html", "class_r_w_a2_1_1_aerial_robot" ],
      [ "AquaticRobot", "class_r_w_a2_1_1_aquatic_robot.html", "class_r_w_a2_1_1_aquatic_robot" ],
      [ "Battery", "class_r_w_a2_1_1_battery.html", "class_r_w_a2_1_1_battery" ],
      [ "LeggedRobot", "class_r_w_a2_1_1_legged_robot.html", "class_r_w_a2_1_1_legged_robot" ],
      [ "MobileRobot", "class_r_w_a2_1_1_mobile_robot.html", "class_r_w_a2_1_1_mobile_robot" ],
      [ "Sensor", "class_r_w_a2_1_1_sensor.html", "class_r_w_a2_1_1_sensor" ],
      [ "WheeledRobot", "class_r_w_a2_1_1_wheeled_robot.html", "class_r_w_a2_1_1_wheeled_robot" ]
    ] ]
];