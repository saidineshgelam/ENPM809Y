var class_r_w_a2_1_1_aquatic_robot =
[
    [ "AquaticRobot", "class_r_w_a2_1_1_aquatic_robot.html#af288fab9f430e04b804b2196e4c270fa", null ],
    [ "move", "class_r_w_a2_1_1_aquatic_robot.html#a1bb8749d0604799f1b6095bb69530673", null ],
    [ "print_status", "class_r_w_a2_1_1_aquatic_robot.html#a3d5b7fbcb1867ee3d5925ad673efffd3", null ],
    [ "rotate", "class_r_w_a2_1_1_aquatic_robot.html#ac56dcbb47a79db60b9c8f29226da21da", null ]
];