var class_r_w_a2_1_1_battery =
[
    [ "Battery", "class_r_w_a2_1_1_battery.html#a8d9d8682226d9b297be77f485da8ea75", null ],
    [ "Battery", "class_r_w_a2_1_1_battery.html#a6538905de23481c1349090fe67acab84", null ],
    [ "discharge", "class_r_w_a2_1_1_battery.html#ad2ca74c95d5a8766eb250b9057dd2667", null ],
    [ "get_battery_model", "class_r_w_a2_1_1_battery.html#a31f7dc4fef66167d6e80c02b70335d35", null ],
    [ "get_current_charge", "class_r_w_a2_1_1_battery.html#ab256696798a2f338fff8fbdc06273866", null ],
    [ "start_charging", "class_r_w_a2_1_1_battery.html#a65c31a8b2f786fa04c52383db001492a", null ]
];