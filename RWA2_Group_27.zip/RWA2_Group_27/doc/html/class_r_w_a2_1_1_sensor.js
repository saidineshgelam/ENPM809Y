var class_r_w_a2_1_1_sensor =
[
    [ "Sensor", "class_r_w_a2_1_1_sensor.html#a3a2bda9d17ccd17daa1a0d52cf7401ad", null ],
    [ "get_sensor_data", "class_r_w_a2_1_1_sensor.html#a1b55d28413ee41eaa78d35a413cf701b", null ],
    [ "read_data", "class_r_w_a2_1_1_sensor.html#acdfc615eb39e41ee210405b222e616cd", null ]
];