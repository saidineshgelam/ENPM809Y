var searchData=
[
  ['get_5fbattery_5fmodel_9',['get_battery_model',['../class_r_w_a2_1_1_battery.html#a31f7dc4fef66167d6e80c02b70335d35',1,'RWA2::Battery']]],
  ['get_5fcurrent_5fcharge_10',['get_current_charge',['../class_r_w_a2_1_1_battery.html#ab256696798a2f338fff8fbdc06273866',1,'RWA2::Battery']]],
  ['get_5fsensor_5fdata_11',['get_sensor_data',['../class_r_w_a2_1_1_sensor.html#a1b55d28413ee41eaa78d35a413cf701b',1,'RWA2::Sensor']]],
  ['get_5fsensor_5freading_12',['get_sensor_reading',['../class_r_w_a2_1_1_mobile_robot.html#a3552c6a9a813d53b9ae3e19f7730b66b',1,'RWA2::MobileRobot']]]
];
