/**
 * RWA2
 * @file AerialRobot.h
 * @brief Contains the declaration of the AerialRobot class.
 *
 */
#pragma once

#include "MobileRobot.h"

namespace RWA2
{
    /**
     * @brief Class for the Aerial robot
     *
     */

    class AerialRobot final : public MobileRobot
    {
    public:
        /**
         * @brief Constructs an AerialRobot object.
         * @param robot_model The model of the robot.
         * @param x The x-coordinate of the robot's position.
         * @param y The y-coordinate of the robot's position.
         * @param orientation The orientation of the robot.
         * @param battery_model The model of the robot's battery.
         * @param current_charge The current battery charge.
         * @param has_wings Indicates whether the robot has wings for flying.
         * @param altitude The current altitude of the robot.
         * @param is_flying Indicates whether the robot is currently flying.
         */
        AerialRobot(std::string Robot_model, double x, double y, double orientation, std::string battery_model, int current_charge, bool has_wings, double altitude, bool is_flying) : MobileRobot(Robot_model, x, y, orientation, battery_model, current_charge), has_wings_{has_wings},
                                                                                                                                                                                       altitude_{altitude}, is_flying_{is_flying}
        {
            //
        }
        /**
         * @brief Lands the aerial robot.
         */
        virtual void move(double distance, double angle) override;
        /**
         * @brief Prints the status of the aerial robot.
         */
        virtual void print_status() override;

    protected:
        /**
         * @brief Rotates the aerial robot.
         * @param angle
         */
        virtual void rotate(double angle) override;

    private:
        void land();
        /**
         * @brief Moves the aerial robot.
         * @param distance The distance to move.
         * @param angle The angle to rotate.
         */
        bool has_wings_;        /**< Indicates whether the robot has wings for flying or not. */
        double altitude_{0.0};  /**< altitude of the robot. */
        bool is_flying_{false}; /**< Indicates whether the robot is currently flying. */
        int max_distance_{50};  /**< The maximum distance the robot can travel. */
        /**
         * @brief Takes off the aerial robot to the specified altitude.
         * @param altitude The altitude to which the robot should take off.
         */

        void take_off(double altitude);
    };

} // namespace RWA2