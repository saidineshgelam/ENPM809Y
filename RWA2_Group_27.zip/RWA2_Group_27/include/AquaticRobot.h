/**
 * @file AquaticRobot.h
 * @brief Contains the declaration of the AquaticRobot class.
 */

#pragma once

#include "MobileRobot.h"

namespace RWA2
{
    /**
     * @brief Class for an Aquatic robot.
     * @details AquaticRobot is a subclass of MobileRobot and adds functionality for underwater robots.
     */

    class AquaticRobot final : public MobileRobot
    {
    public:
        /**
         * @brief Moves the aquatic robot.
         * @param distance Distance to move
         * @param angle Angle to rotate
         */
        virtual void move(double distance, double angle) override;
        /**
         * @brief Prints the status of the aquatic robot.
         */
        virtual void print_status() override;
        /**
         * @brief Constructs an AquaticRobot object.
         * @param robot_model The model of the robot.
         * @param x The x-coordinate of the robot's position.
         * @param y The y-coordinate of the robot's position.
         * @param orientation The orientation of the robot.
         * @param battery_model The model of the robot's battery.
         * @param current_charge The current battery charge.
         * @param has_fins Indicates whether the robot has fins for swimming.
         * @param depth The current depth of the robot.
         * @param is_diving Indicates whether the robot is currently diving or not.
         */
        AquaticRobot(std::string Robot_model, double x, double y, double orientation, std::string battery_model, int current_charge, bool has_fins_, double depth_, bool is_diving_)
            : MobileRobot(Robot_model, x, y, orientation, battery_model, current_charge), has_fins_{has_fins_}, depth_{depth_}, is_diving_{is_diving_}
        {
        }

    protected:
        /**
         * @brief Rotates the aquatic robot.
         * @param angle angle to rotate.
         */
        virtual void rotate(double angle) override;

    private:
        bool has_fins_;          /**< Indicates whether the robot has fins for swimming. */
        double depth_ = 0.0;     /**< The current depth of the robot. */
        bool is_diving_ = false; /**< Indicates whether the robot is currently diving. */

        /**
         * @brief Dives the aquatic robot to the specified depth.
         * @param depth The depth to which the robot should dive.
         */
        void dive(double depth);
        /**
         * @brief Surfaces the aquatic robot.
         */
        void surface();
    };
} // namespace RWA2