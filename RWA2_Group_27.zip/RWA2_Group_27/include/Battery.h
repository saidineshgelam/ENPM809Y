/**
 * @file Battery.h
 * @brief Contains the declaration of the Battery class.
 */
#pragma once

#include <iostream>
#include <memory>
#include <thread>
#include <utility>

namespace RWA2
{
    /**
     * @brief Class for Battery.
     */

    class Battery
    {
    public:
        /**
         * @brief Constructs a Battery object.
         * @param model The model of the battery.
         * @param current_charge The initial charge level of the battery.
         * @param is_charging Indicates whether the battery is currently charging.
         */
        Battery(std::string model, int current_charge, bool is_charging) : model_{model},
                                                                           current_charge_{current_charge},
                                                                           is_charging_{is_charging}
        {
        }
        Battery(){}
        /**
         * @brief Starts charging the battery.
         */

        void start_charging();

        /**
         * @brief Discharges the battery by a specified amount.
         * @param amount The amount to discharge the battery.
         */
        void discharge(double amount);
        /**
         * @brief Gets the current charge level of the battery.
         * @return The current charge level.
         */

        double get_current_charge() { return current_charge_; }
        /**
         * @brief Gets the model of the battery.
         * @return The model of the battery.
         */
        std::string get_battery_model() { return model_; }

    private:
        std::string model_;  /**< The model of the battery. */
        int current_charge_; /**< The current charge level of the battery. */
        bool is_charging_;   /**< Indicates whether the battery is currently charging. */

        /**
         * @brief Stops charging the battery.
         */
        void stop_charging();
    };

} // namespace RWA2