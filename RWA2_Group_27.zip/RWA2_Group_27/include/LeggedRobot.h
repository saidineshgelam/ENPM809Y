/**
 * @file LeggedRobot.h
 * @brief Contains the declaration of the LeggedRobot class.
 */

#pragma once

#include "MobileRobot.h"

namespace RWA2
{
    /**
     * @brief Class for legged robot.
     * @details LeggedRobot is a subclass of MobileRobot and adds functionality for robots with legs.
     */

    class LeggedRobot final : public MobileRobot
    {
    public:
        /**
         * @brief Constructs a LeggedRobot object.
         * @param Robot_model The model of the robot.
         * @param x The x-coordinate of the robot's position.
         * @param y The y-coordinate of the robot's position.
         * @param orientation The orientation of the robot.
         * @param battery_model The model of the robot's battery.
         * @param current_charge The current battery charge.
         * @param leg_strength The strength of the robot's legs.
         * @param height The height of the robot.
         * @param number_of_legs The number of legs on the robot.
         */
        LeggedRobot(std::string Robot_model, double x, double y, double orientation, std::string battery_model, int current_charge, int leg_strength, double height, int number_of_legs) : MobileRobot(Robot_model, x, y, orientation, battery_model, current_charge), leg_strength_{leg_strength}, height_{height}, number_of_legs_{number_of_legs}
        {
            //
        }
        /**
         * @brief Moves the legged robot.
         * @param distance The distance to move.
         * @param angle The angle at which to move.
         */
        virtual void move(double distance, double angle) override;
        /**
         * @brief Prints the status of the legged robot.
         */
        virtual void print_status() override;

    protected:
        /**
         * @brief Rotates the legged robot.
         * @param angle The angle to rotate.
         */
        virtual void rotate(double angle) override;

    private:
        int leg_strength_; /** strength in robots leg*/
        double height_;    /**< The height of the legged robot. */
        int number_of_legs_{2};        /** Then no of legs on the robot*/
        int battery_required_kick_{1}; /**The battery power required for a kick*/
        double max_distance_{10.0};    /**The max distance robot can travel*/
        /**
         * @brief Performs a kicking action.
         */
        void kick();

        /**
         * @brief Makes the legged robot jump by a specified amount.
         * @param amount The amount to jump.
         */
        void jump(double amount);
    }; // class LeggedRobot

} // namespace RWA2