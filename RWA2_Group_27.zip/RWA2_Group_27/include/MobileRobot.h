/**
 * @file MobileRobot.h
 * @brief Contains the declaration of the MobileRobot class.
 */

#pragma once
#include <iostream>
#include <memory>
#include <utility>
#include <vector>
#include "Battery.h"
#include "Sensor.h"

namespace RWA2
{
    /**
     * @brief Class for the mobile robot
     *
     */
    class MobileRobot
    {
    public:
        /**
         * @brief Constructs a MobileRobot object.
         * @param Robot_model The model of the robot.
         * @param x The x-coordinate of the robot's initial position.
         * @param y The y-coordinate of the robot's initial position.
         * @param orientation The initial orientation of the robot.
         * @param battery_model The model of the robot's battery.
         * @param current_charge The initial battery charge.
         */
        MobileRobot(std::string Robot_model, double x, double y, double orientation, std::string battery_model, int current_charge) : model_{Robot_model}, position_{x, y}, orientation_{orientation}, battery_{battery_model, current_charge, false}
        {
        }
        /**
         * @brief Moves the mobile robot.
         * @param distance The distance to move.
         * @param angle The angle at which to move.
         */
        virtual void move(double distance, double angle);
        /**
         * @brief Prints the status of the mobile robot.
         */
        virtual void print_status();
        /**
         * @brief Adds a sensor to the mobile robot.
         * @param sensor A unique pointer to a Sensor object.
         */
        void add_sensor(std::unique_ptr<RWA2::Sensor> sensor);

        /**
         * @brief Get the sensor reading
         * @param period period of the sensor reading
         * @return an array of sensor readings
         */
        std::array<double, 50> get_sensor_reading(int period);

    protected:
        std::string model_;                                  /**< The model of the robot. */
        std::pair<double, double> position_;                 /**< The current position of the robot. */
        double orientation_;                                 /**< The current orientation of the robot. */
        double speed_ = 0.0;                                 /**< The current speed of the robot. */
        RWA2::Battery battery_;                              /**< The battery of the robot. */
        std::vector<std::unique_ptr<RWA2::Sensor>> sensors_; /**< The sensors attached to the robot. */

        /**
         * @brief Rotates the mobile robot.
         * @param angle The angle to rotate.
         */

        virtual void rotate(double angle) = 0;

    private:
        std::array<double, 50> sensor_reading; /**< An array to store sensor readings. */
    };                                         // class mobile robot
} // namespace RWA2