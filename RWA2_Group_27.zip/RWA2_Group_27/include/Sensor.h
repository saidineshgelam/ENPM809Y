/**
 * @file Sensor.h
 * @brief Contains the declaration of the Sensor class.
 */

#pragma once

#include <iostream>
#include <memory>
#include <thread>
#include <utility>
#include <array>

namespace RWA2
{
    /**
     * @brief Class for a sensor.
     * @details Sensor is a class for collecting and storing data from a sensor.
     */

    class Sensor final
    {
    public:
        /**
         * @brief Constructs a Sensor object.
         * @param model The model of the sensor.
         */
        Sensor(std::string model)
            : model_{model} {}
        /**
         * @brief Reads data from the sensor for a specified duration.
         * @param duration The duration for which to read data.
         */
        void read_data(unsigned int duration);
        /**
         * @brief Gets the sensor data.
         * @return An array containing sensor data.
         */
        std::array<double, 50> get_sensor_data();

    private:
        std::string model_;           /**< The model of the sensor. */
        std::array<double, 50> data_; /**< An array to store sensor data. */

    }; // class Sensor

} // namespace RWA2