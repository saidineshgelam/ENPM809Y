/**
 * @file WheeledRobot.h
 * @brief Contains the declaration of the WheeledRobot class.
 */
#pragma once

#include "MobileRobot.h"

namespace RWA2
{
    /**
     * @brief CLass for a wheeled robot.
     * @details WheeledRobot is a subclass of MobileRobot and adds functionality for robots with wheels.
     */

    class WheeledRobot final : public MobileRobot
    {
    private:
        int number_of_wheels_ = 2; /**< The number of wheels on the robot. */
        double wheel_diameter_;    /**< The diameter of the wheels. */
        double desired_speed_;     /**< The desired speed of the robot. */

        /**
         * @brief Accelerates the wheeled robot.
         * @param amount The amount by which to accelerate.
         */
        void accelerate(double amount);

        /**
         * @brief Decelerates the wheeled robot.
         * @param amount The amount by which to decelerate.
         */
        void decelerate(double amount);
        /**
         * @brief Applies the brakes to the wheeled robot.
         */
        void brake();

    public:
        /**
         * @brief Moves the wheeled robot.
         * @param distance The distance to move.
         * @param angle The angle at which to move.
         */
        virtual void move(double distance, double angle) override;
        /**
         * @brief Prints the status of the wheeled robot.
         */
        virtual void print_status() override;
        /**
         * @brief Constructs a WheeledRobot object.
         * @param Robot_model The model of the robot.
         * @param x The x-coordinate of the robot's position.
         * @param y The y-coordinate of the robot's position.
         * @param orientation The orientation of the robot.
         * @param battery_model The model of the robot's battery.
         * @param current_charge The current battery charge.
         * @param number_of_wheels The number of wheels on the robot.
         * @param wheel_diameter The diameter of the wheels.
         * @param desired_speed The desired speed of the robot.
         */
        WheeledRobot(std::string Robot_model, double x, double y, double orientation, std::string battery_model, int current_charge, int number_of_wheels_, double wheel_diameter_, double desired_speed_)
            : MobileRobot(Robot_model, x, y, orientation, battery_model, current_charge), number_of_wheels_{number_of_wheels_}, wheel_diameter_{wheel_diameter_}, desired_speed_{desired_speed_}
        {
        }

    protected:
        /**
         * @brief Rotates the wheeled robot.
         * @param angle The angle to rotate.
         */
        virtual void rotate(double angle) override;
    };//class wheel robot
}
// namespace RWA2
