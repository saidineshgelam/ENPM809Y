Unzip the workspace
The folder has .vscode, include and src folders
Make sure that your system has  a C++ compiler (e.g., g++).
Run the main.cpp

Note: Ensure that you have the required C++ compiler and dependencies installed on your system.

Contributors:
1.Sai Dinesh Gelam-120167140
2.Raghu dharahas reddy kotla-120378935
3.Sriram Prasad kothapalli-120165177