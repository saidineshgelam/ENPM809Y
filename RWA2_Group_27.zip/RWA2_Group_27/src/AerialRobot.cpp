
#include "AerialRobot.h"
#include <chrono>
#include <thread>
// AerialRobot implementation
//  Function to print the status of the AerialRobot
void RWA2::AerialRobot::print_status()
{
    std::cout << AerialRobot::model_ << " Has Wings : " << std::boolalpha << has_wings_ << "\n"
              << "Altitude : " << altitude_ << "\n"
              << "Is Flying :" << std::boolalpha << is_flying_ << '\n';
    std::cout << "Position of the mobile robot is (" << position_.first << ", " << position_.second << ")" << '\n';
    std::cout << "Orientation of the mobile robot is " << orientation_ << " degrees" << '\n';
    std::cout << "Velocity of the mobile robot is " << speed_ << '\n';
    std::cout << "..................................................................\n";
    std::cout << "\n";
    std::cout << "\n";
    std::cout << "\n";
}
// Function to move the AerialRobot by a given distance and angle
void RWA2::AerialRobot::move(double distance, double angle)
{
    // Check if there is enough battery to cover the distance
    if (distance <= max_distance_)
    {
        // if not enough battery then start charging
        if (battery_.get_current_charge() < (2 * distance))
        {
            battery_.start_charging();
        }
        // to get sensor readings for 4 seconds
        get_sensor_reading(4);
        // to perform take-off, rotate and landing
        take_off(distance);
        rotate(angle);
        land();
        // To display information about the aerial robots status
        std::cout << AerialRobot::model_ << " reached an altitude of " << distance << " meters and then landed."
                  << "\n";
        std::cout << "Current Battery Charge : " << battery_.get_current_charge() << "\n";
        print_status();
    }
    else
    {
        // To prompt user if insufficient battery is available
        std::cout << AerialRobot::model_ << " Insufficient battery capacity to cover given distance";
    }
}
// function to rotate the robot by given angle
void RWA2::AerialRobot::rotate(double angle)
{
    // update the orientation
    orientation_ = orientation_ + angle;
    std::cout << AerialRobot::model_ << " rotated " << orientation_ << " degrees" << '\n';
}
// function to perform take-off task for specified altitude
void RWA2::AerialRobot::take_off(double altitude)
{
    if (!is_flying_)
    {
        int time{0};
        // to calculate the take-off time
        if (has_wings_)
        {
            time = altitude / 3.0;
        }
        else
        {
            time = altitude / 1.5;
        }
        std::cout << AerialRobot::model_ << " is taking off...it takes  " << time << " seconds \n";
        // simulate the take-off using thread sleep
        std::chrono::seconds duration(time);
        std::this_thread::sleep_for(duration);

        std::cout << AerialRobot::model_ << " took off and reached the altitude: " << altitude << "\n";
        altitude_ = altitude;
        is_flying_ = true;
        battery_.discharge(altitude_);
    }
}
// Function to land the aerial robot
void RWA2::AerialRobot::land()
{

    if (is_flying_)
    {
        int time{0};

        if (has_wings_)
        {
            time = altitude_ / 4.0;
        }
        else
        {
            time = altitude_ / 2.0;
        }
        std::cout << AerialRobot::model_ << " landing...\n ";

        std::chrono::seconds duration(time);
        std::this_thread::sleep_for(duration);

        std::cout << AerialRobot::model_ << " landed:\n ";
        // Discharge the battery and reset altitude and flying status
        battery_.discharge(altitude_);
        altitude_ = 0.0;
        is_flying_ = false;
    }
}