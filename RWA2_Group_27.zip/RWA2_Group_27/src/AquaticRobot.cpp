
#include "AquaticRobot.h"

// AquaticRobot implementation
// To print the status of the aquatic robot
void RWA2::AquaticRobot::print_status()
{
    // to print info about the aquaticrobot
    std::cout << AquaticRobot::model_ << " has Fins : " << std::boolalpha << has_fins_ << "\n"
              << "Depth : " << depth_ << "\n"
              << "Is Diving : " << std::boolalpha << is_diving_ << '\n';
    std::cout << "Position of the mobile robot is (" << position_.first << ", " << position_.second << ")" << '\n';
    std::cout << "Orientation of the mobile robot is " << orientation_ << " degrees" << '\n';
    std::cout << "Velocity of the mobile robot is " << speed_ << '\n';
    std::cout << "Battery " << battery_.get_battery_model() << " has charge " << battery_.get_current_charge() << '\n';
    std::cout << "_________________________________________________________________________________________\n";
    std::cout << "\n";
    std::cout << "\n";
    std::cout << "\n";
    return;
}

// function to rotate the aquaticrobot by a given angle
void RWA2::AquaticRobot::rotate(double angle)
{
    orientation_ = orientation_ + angle;

    std::cout << "The " << AquaticRobot::model_ << " rotated " << angle << " degrees" << std::endl;
    return;
}

// Function to move the robot by a given distance and angle
void RWA2::AquaticRobot::move(double distance, double angle)
{
    // check if distance is in range
    if (distance <= 50)
    {
        // check if there is enough battery to acomplish the task
        if (battery_.get_current_charge() < distance * 2)
        {
            // charge the battery
            battery_.start_charging();
        }
        get_sensor_reading(5);

        rotate(angle);
        std::cout << "Moving down " << distance << " m\n";
        dive(distance);
        std::cout << "Robot moved to desired depth " << distance << " m\n";
        // move robot to the Surface
        std::cout << "Moving upward " << depth_ << " m\n";
        surface();
        std::cout << "Robot is on surface " << depth_ << " m\n";

        std::cout << AquaticRobot::model_ << " reached a depth of " << distance << " meters and then surfaced.\n";

        print_status();
    }

    return;
}

// function to move the aquatic robot to dive a specified depth
void RWA2::AquaticRobot::dive(double depth)
{
    int swim_time_{0};
    if (!is_diving_)
    {
        std::cout << "Robot is diving\n";

        if (has_fins_)
        {
            // it has fins and travels at 2 m/s
            speed_ = 2;
            swim_time_ = depth / speed_;
        }
        else
        {
            // it does not have fins and travels at 1 m/s
            speed_ = 1;
            swim_time_ = depth / speed_;
        }
        // Simulate the dive duration using thread sleep
        std::chrono::seconds duration(swim_time_);
        std::this_thread::sleep_for(duration);
        depth_ = depth;
        is_diving_ = true;
        battery_.discharge(depth_); // Consume battery charge
    }
    return;
}
// function to make the robot move back to surface
void RWA2::AquaticRobot::surface()
{
    int swim_time_{0};

    if (is_diving_)
    {
        std::cout << "Robot is surfacing\n";
        // Determine swim time based on whether the robot has fins
        if (has_fins_)
        {
            swim_time_ = depth_ / 4;
        }
        else
        {
            // it does not have fins and travels at 2 m/s
            swim_time_ = depth_ / 2;
        }
        // sleep code for the duration of the dive
        std::chrono::seconds duration(swim_time_);
        std::this_thread::sleep_for(duration);
        battery_.discharge(depth_);
        depth_ = 0.0;
        is_diving_ = false;
    }    
    return;
}
