
#include <chrono>
#include <thread>

#include "Battery.h"


// Battery implementation
//  function to start charging the battery
void RWA2::Battery::start_charging()
{
    int charge_time_ = 0;
    if (!is_charging_)
    {
        // determine charge time based on the battery model
        if (model_ == "Li-ion")
        {
            charge_time_ = ((100 - current_charge_) / 2);
        }
        else if (model_ == "LiFePO4")
        {
            charge_time_ = ((100 - current_charge_) / 4);
        }

        is_charging_ = true;
        std::cout << "Battery  " << model_ << " is charging" << '\n';
        // simulate the charging time using thread sleep
        std::chrono::seconds duration(charge_time_);
        std::this_thread::sleep_for(duration);
        stop_charging();
        current_charge_ = int(100);
    }
}
// function to discharge the battery by a specified amount
void RWA2::Battery::discharge(double amount)
{
    
    current_charge_ = current_charge_- amount;
    std::cout <<"Current_charge: " << current_charge_ << "\n";
}

// Function to stop charging the battery
void RWA2::Battery::stop_charging()
{
    is_charging_ = false;
    std::cout << "Battery  " << model_ << "is fully charged" << "\n";
}