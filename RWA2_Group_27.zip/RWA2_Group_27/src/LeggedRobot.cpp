
#include "LeggedRobot.h"

//  LeggedRobot implementation
// function to move the leggedrobot by a given distance and angle
void RWA2::LeggedRobot::move(double distance, double angle)
{
    // calculate the battery required to accomplish task
    int battery_required = distance * leg_strength_ + leg_strength_ * battery_required_kick_;
    // check if the distance is within a reasonable range
    if (distance <= max_distance_)
    {

        if (battery_.get_current_charge() < battery_required)
        {
            battery_.start_charging();
        }
        get_sensor_reading(5);
        rotate(angle);
        jump(distance);
        kick();
        print_status();
    }
    else
    {
        
        std::cout << LeggedRobot::model_ << "The robot is unable to cover the specified distance because of insufficient battery capacity.";
    }
}

// function to print the status of the legged robot
void RWA2::LeggedRobot::print_status()
{
    std::cout << LeggedRobot::model_ << " has " << number_of_legs_ << " legs "<<"\n"
              << "and can jump up to max height of : " << height_ << " with leg strength " << leg_strength_ << "\n";
    std::cout << "Position of the mobile robot is (" << position_.first << ", " << position_.second << ")" << '\n';
    std::cout << "Orientation of the mobile robot is " << orientation_ << " degrees" << '\n';
    std::cout << "Velocity of the mobile robot is " << speed_ << '\n';
    std::cout << "Battery " << battery_.get_battery_model() << " has charge " << battery_.get_current_charge() << '\n';

    std::cout << "._._._._._._._._._._._._._._._._._.\n";
    std::cout << "\n";
    std::cout << "\n";
    std::cout << "\n";
}
// function to rotate the legged robot by a given angle
void RWA2::LeggedRobot::rotate(double angle)
{
    std::cout << LeggedRobot::model_ << " rotated " << angle << " degrees.\n";
}
// function for the robot to perfom the kick
void RWA2::LeggedRobot::kick()
{
    std::cout << LeggedRobot::model_ << " kicks with a strength of " << leg_strength_ << "\n";
    battery_.discharge(leg_strength_ * battery_required_kick_);
}
// function for robot to perform a jump
void RWA2::LeggedRobot::jump(double amount)
{
    std::cout << LeggedRobot::model_ << " jumps at a height of " << amount << "  cm above the ground\n";
    // discharge the battery
    battery_.discharge(leg_strength_ * amount);
}