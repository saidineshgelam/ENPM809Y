
#include "MobileRobot.h"

//  MobileRobot implementation

// move function
void RWA2::MobileRobot::move(double distance, double angle)
{
  // implementation specific to each type of mobile robot
}

// print the current status of the mobile robot
void RWA2::MobileRobot::print_status()
{
  std::cout << "Position of the mobile robot is (" << position_.first << ", " << position_.second << ")" << '\n';
  std::cout << "Orientation of the mobile robot is " << orientation_ << " degrees" << '\n';
  std::cout << "Velocity of the mobile robot is " << speed_ << '\n';
}

// rotate the mobile robot by a specified angle
void RWA2::MobileRobot::rotate(double angle)
{
  orientation_ = orientation_ + angle;
  std::cout << "Rotating " << orientation_ << " degrees" << '\n';
}
// add a sensor to the robot
void RWA2::MobileRobot::add_sensor(
    std::unique_ptr<RWA2::Sensor> sensor)
{
  sensors_.push_back(std::move(sensor));
}
// get sensor readings
std::array<double, 50> RWA2::MobileRobot::get_sensor_reading(int period)
{
  for (auto it = sensors_.begin(); it != sensors_.end(); ++it)
  {
    (*it)->read_data(period);
  }
  // retrieve sensor data from each sensor
  for (auto it = sensors_.begin(); it != sensors_.end(); ++it)
  {
    sensor_reading = (*it)->get_sensor_data();
  }

  return sensor_reading;
}