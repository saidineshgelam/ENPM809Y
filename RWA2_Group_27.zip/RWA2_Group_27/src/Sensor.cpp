
#include "Sensor.h"
#include <chrono>
#include <iostream>
#include <thread>
#include <random>

//  Sensor implementation
// Read data from sensor for a specifies duration
void RWA2::Sensor::read_data(unsigned int duration)
{

    std::cout << "Sensor " << model_ << "  gathering data for " << duration << " seconds\n";
    std::this_thread::sleep_for(std::chrono::seconds(duration));
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> dis(1.0, 30.0);
    //populate the sensors data array with random values
    for (unsigned int i = 0; i < data_.size(); ++i)
    {
        data_[i] = dis(gen);
    }
    std::cout << "Sensor " << model_ << " read data: 0\n";
    for (unsigned int i = 0; i < data_.size(); ++i)
    {
        std::cout << data_[i] << " , ";
    }
    std::cout << '\n'<<"\n";
}
// get sensors data
std::array<double, 50> RWA2::Sensor::get_sensor_data()
{
    return data_;
}