
#include "WheeledRobot.h"

//  WheeledRobot implementation
// print the status of the wheeled robot
void RWA2::WheeledRobot::print_status()
{
    std::cout << WheeledRobot::model_ << "Has : " << number_of_wheels_
              << " wheels "
              << " Desired speed : " << desired_speed_ << std::endl;
    std::cout << "Position of the mobile robot is (" << position_.first << ", "
              << position_.second << ")" << '\n';
    std::cout << "Orientation of the mobile robot is " << orientation_
              << " degrees" << '\n';
    std::cout << "Velocity of the mobile robot is " << speed_ << '\n';
    std::cout << "Battery " << battery_.get_battery_model() << " has charge " << battery_.get_current_charge() << '\n';

    std::cout << WheeledRobot::model_ << "Has : " << number_of_wheels_
              << " wheels "
              << " Desired speed : " << desired_speed_ << std::endl;

    std::cout << ".....................................................................\n";
    std::cout << "\n";
    std::cout << "\n";
    
    
    return;
}
// move the wheeled robot for a specified distance and angle
void RWA2::WheeledRobot::move(double distance, double angle)
{
    // chech if the distance is within the range
    if (distance <= 100.0)
    {
        if (battery_.get_current_charge() < distance)
        {
            // charge the battery
            battery_.start_charging();
        }
        get_sensor_reading(5); // read sensor data
        rotate(angle);
        accelerate(2.0); //accelerate to the desired speed
        // simulate moving forward for specific duration
        std::chrono::seconds duration(static_cast<int>(distance - 2.0));
        std::this_thread::sleep_for(duration);
        decelerate(2.0); //decelerate to stop
        brake();
        std::cout << WheeledRobot::model_ << " drove " << distance << " m." << std::endl;
        battery_.discharge(distance);//discharge the battery based on the distance traveled
        print_status();

    }
    return;
}

// rotate the wheeled robot by a specfied angle 
void RWA2::WheeledRobot::rotate(double angle)
{
    std::cout << WheeledRobot::model_ << " rotated " << angle << " degrees."
              << std::endl;
    return;
}

// to accelerate the wheeled robot to the desired speed
void RWA2::WheeledRobot::accelerate(double amount)
{
    while (speed_ < desired_speed_)
    {
        speed_ += amount;
        std::chrono::seconds duration(static_cast<int>(0.5));
        std::this_thread::sleep_for(duration);
    }
    std::cout << WheeledRobot::model_ << " has reached the desired speed of " << desired_speed_ << " m/s." << std::endl;
    return;
}

// decelerate the wheeled robot to stop
void RWA2::WheeledRobot::decelerate(double amount)
{
    while (speed_ >= 0.0)
    {
        speed_ -= amount;
        std::chrono::seconds duration(static_cast<int>(0.5));
        std::this_thread::sleep_for(duration);
    }
    std::cout << WheeledRobot::model_ << " is decelarating\n";
    return;
}

// to stop the robot
void RWA2::WheeledRobot::brake()
{
    speed_ = 0.0;
    std::cout << WheeledRobot::model_ << " has stoped \n";
    return;
}
