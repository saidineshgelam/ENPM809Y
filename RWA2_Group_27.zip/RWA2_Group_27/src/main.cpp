#include <iostream>
#include <memory>
#include <vector>
#include "MobileRobot.h"
#include "AerialRobot.h"
#include "LeggedRobot.h"
#include "WheeledRobot.h"
#include "AquaticRobot.h"

// function to display the status of mobile robots
void get_status(const std::vector<std::unique_ptr<RWA2::MobileRobot>> &robots)
{
    // iterate through the vector of robots and print their status
    for (auto it = robots.cbegin(); it != robots.cend(); ++it)
    {
        const auto &robot = *it;
        robot->print_status();
        std::cout << "======================================\n";
        std::cout << "\n" << "\n" <<"\n";    
    }
}
// function to move the mobile robot
void move_robot(const std::vector<std::unique_ptr<RWA2::MobileRobot>> &robots)
{
    // iterate through the vector of robots and move them
    for (auto it = robots.cbegin(); it != robots.cend(); ++it)
    {
        const auto &robot = *it;
        robot->move(5.0, 5.0);
    }
}

// functions to add sensors to mobile robots
void add_sensor(const std::vector<std::unique_ptr<RWA2::MobileRobot>> &robots)
{
    for (const auto &robot : robots)
    {
        // Generate a random number (0 or 1)
        int randomValue = std::rand() % 2;

        // Add a sensor based on the random number
        if (randomValue == 0)
        {
            robot->add_sensor(std::make_unique<RWA2::Sensor>("OSDome"));
        }
        else
        {
            robot->add_sensor(std::make_unique<RWA2::Sensor>("LD-MRS"));
        }
    }
}
// main function
int main()
{
    std::vector<std::unique_ptr<RWA2::MobileRobot>> mobile_robots;
    // adding unique pointers to different types of mobile robots
    std::unique_ptr<RWA2::MobileRobot> Atlas_robot =
        std::make_unique<RWA2::LeggedRobot>("Atlas", 0.0, 0.0, 0.0, "Li-ion", 80, 2, 0.5, 2);
    std::unique_ptr<RWA2::MobileRobot> crazyflie_robot =
        std::make_unique<RWA2::AerialRobot>("CrazyFlie", 0.0, 0.0, 0.0, "LiFePO4", 70, false, 0, false);
    std::unique_ptr<RWA2::MobileRobot> HoloOcean_robot =
        std::make_unique<RWA2::AquaticRobot>("HoloOcean", 0.0, 0.0, 0.0, "Li-ion", 90, false, 10, false);
    std::unique_ptr<RWA2::MobileRobot> Hiwonder_robot =
        std::make_unique<RWA2::WheeledRobot>("Hiwonder", 3.0, 0.0, 0.0, "LiFePO4", 95, 4, 0.1, 2);
    std::unique_ptr<RWA2::MobileRobot> erle_plane_robot =
        std::make_unique<RWA2::AerialRobot>("Erle-Plane", 0.0, 0.0, 0.0, "Li-ion", 85, true, 0, false);
    // add the unique pointers to the vector
    mobile_robots.push_back(std::move(erle_plane_robot));
    mobile_robots.push_back(std::move(crazyflie_robot));
    mobile_robots.push_back(std::move(Hiwonder_robot));
    mobile_robots.push_back(std::move(HoloOcean_robot));
    mobile_robots.push_back(std::move(Atlas_robot));
    add_sensor(mobile_robots); //add sensors to mobile robots
    move_robot(mobile_robots); //move the robots
    //get_status(mobile_robots); //Display the status list of all mobile robots
}